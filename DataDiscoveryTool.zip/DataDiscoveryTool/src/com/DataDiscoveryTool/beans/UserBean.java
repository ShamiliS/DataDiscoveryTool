package com.DataDiscoveryTool.beans;

public class UserBean {

	private String DBName;
	private String HostName;
	private Long PortNumber;
	private String SID;
	private String UserName;
	private String Password;
	private String Schema;
	public boolean valid;

	public UserBean() {
	}

	public String getDBName() {
		return DBName;
	}

	public void setDBName(String dBName) {
		this.DBName = dBName;
	}

	public String getHostName() {
		return HostName;
	}

	public void setHostName(String hostName) {
		this.HostName = hostName;
	}

	public Long getPortNumber() {
		return PortNumber;
	}

	public void setPortNumber(Long portNumber) {
		this.PortNumber = portNumber;
	}

	public String getSID() {
		return SID;
	}

	public void setSID(String sID) {
		this.SID = sID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		this.UserName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}

	public String getSchema() {
		return Schema;
	}

	public void setSchema(String schema) {
		this.Schema = schema;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean newValid) {
		valid = newValid;
	}

}
