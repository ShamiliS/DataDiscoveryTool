package com.DataDiscoveryTool.Servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RetrieveDataServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			ArrayList<String> user = new ArrayList<String>();

			user = UserDAO.login(request);

			if (user != null) {
				System.out.println("user values are ::: " + user);
				request.getSession().setAttribute("TableNames", user);
				getServletConfig().getServletContext().getRequestDispatcher("/Frames.jsp").include(request, response);

			} else
				response.sendRedirect("invalidLogin.jsp"); // error page
		} catch (Throwable theException) {
			System.out.println(theException);
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			ArrayList<String> user = new ArrayList<String>();

			user = UserDAO.login(request);

			if (user != null) {
				// RequestDispatcher dispatcher = request.getRequestDispatcher("/Frames.jsp");
				System.out.println("user values are ::: " + user);
				request.setAttribute("TableNames", user);
				// dispatcher.forward(request, response);
				getServletConfig().getServletContext().getRequestDispatcher("/ListofTable.jsp").include(request,
						response);
			} else
				response.sendRedirect("invalidLogin.jsp"); // error page
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
